You are free to clone, modify Lambda and make pull requests, provided you follow
the [license](https://github.com/lambda-client/lambda/blob/master/LICENSE.md).

Before contributing please see the [Code of Conduct](https://github.com/lambda-client/lambda/blob/master/.github/CODE_OF_CONDUCT.md).

See [Support](https://github.com/lambda-client/lambda/issues) for help.

See this [this](https://github.com/lambda-client/lambda#contributing) page for contributing instructions.
