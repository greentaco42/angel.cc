---
name: Incompatibility Report
about: Module incompatibility or incompatible with another Forge mod
labels: -incompatible
---

**What mod/module causes an issue?**
<!-- Mention the problematic mod/module here. -->

**What issue is caused?**
<!-- Provide a clear and concise description of the issue -->

**Please attach your Minecraft logs**
<!-- Please add logs or your issue will be closed, as we need to see the logs to accurately troubleshoot. -->

**Additional context**
<!-- Add any other context about the problem here, such as a more detailed description, or attach related media. -->
