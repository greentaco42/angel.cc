package com.lambda.client.commons.interfaces

interface Nameable {
    val name: String
}