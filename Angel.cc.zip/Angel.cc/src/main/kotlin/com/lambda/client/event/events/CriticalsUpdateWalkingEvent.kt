package com.lambda.client.event.events

import com.lambda.client.event.Event

/**
 * @author Doogie13
 * @since 20/12/2022
 */
class CriticalsUpdateWalkingEvent : Event