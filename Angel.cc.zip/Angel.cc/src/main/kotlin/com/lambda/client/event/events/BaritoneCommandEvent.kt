package com.lambda.client.event.events

import com.lambda.client.event.Event

class BaritoneCommandEvent(val command: String) : Event