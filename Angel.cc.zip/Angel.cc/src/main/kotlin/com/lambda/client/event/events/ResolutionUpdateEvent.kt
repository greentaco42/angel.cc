package com.lambda.client.event.events

import com.lambda.client.event.Event

class ResolutionUpdateEvent(val width: Int, val height: Int) : Event